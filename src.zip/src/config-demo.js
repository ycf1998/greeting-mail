// 把文件名改为config.js
module.exports = {
    // 邮箱密钥
    mailPass: '',
    // 百度天气密钥
    baiduWeatherAk: '',
    // 数据库连接信息 
    db: {
        host: '',
        port: '',
        user: '',
        password: ''
    }
}