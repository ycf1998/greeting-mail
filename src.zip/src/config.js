module.exports = {
    mailPass: 'aqzhvhajqebqbgjh',
    baiduWeatherAk: 'XrCwqRDkfsrUMOwPq58Gc2Uh1malUrFQ',
    db: {
        host: '175.178.102.32',
        port: 3306,
        user: 'root',
        password: 'Ycf1998.'
    }
}